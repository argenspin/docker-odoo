This module allows viewing projects as list.
